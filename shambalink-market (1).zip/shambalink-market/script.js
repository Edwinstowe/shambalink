const $=id=>document.getElementById(id);
const esc=s=>String(s==null?'':s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const DAY=864e5,now=Date.now(),iso=d=>new Date(d).toISOString().slice(0,10),today=iso(now);
const ago=t=>{const h=Math.round((Date.now()-t)/36e5);return h<1?'just now':h<48?h+'h ago':Math.round(h/24)+'d ago'};
const money=n=>'KES '+Number(n).toLocaleString('en-US');
const tag=(t,c)=>`<span class="tag ${c||String(t).replace(/\W/g,'')}">${esc(t)}</span>`;
const card=h=>`<div class="card">${h}</div>`;
const btn=(t,f,c)=>`<button class="btn sm ${c||''}" onclick="${f}">${t}</button>`;
const empty=t=>`<div class="empty">${t}</div>`;
const stat=(n,l,c)=>`<div class="card stat"><b class="${c||''}">${n}</b>${l}</div>`;
const bars=rows=>{const mx=Math.max(1,...rows.map(r=>r[1]));return rows.map(([l,v])=>`<div class="bar"><span>${esc(l)}</span><i style="width:${Math.max(3,v/mx*60)}%"></i><b>${v}</b></div>`).join('')};
const toast=m=>{const t=$('toast');t.textContent=m;t.style.display='block';clearTimeout(toast.h);toast.h=setTimeout(()=>t.style.display='none',2800)};

const KEY='fm',ROLES=['Farmer','Buyer','Transporter'],PROFROLE='',PROFLABEL='',PROF=[];
function seed(){return{lst:[
{id:1,farmer:'Wanjiku Mwangi',produce:'Tomatoes',qty:200,unit:'kg',price:60,loc:'Kiambu',at:now-DAY},
{id:2,farmer:'Hassan Omondi',produce:'Maize',qty:50,unit:'90kg bag',price:3200,loc:'Nakuru',at:now-2*DAY},
{id:3,farmer:'Wanjiku Mwangi',produce:'Kale (sukuma wiki)',qty:80,unit:'kg',price:40,loc:'Kiambu',at:now-3e7}],
ord:[],prices:[{p:'Tomatoes',price:75,unit:'kg'},{p:'Maize',price:3400,unit:'90kg bag'},{p:'Kale (sukuma wiki)',price:45,unit:'kg'},{p:'Potatoes',price:55,unit:'kg'}],
comps:[],notes:[],seq:4,oseq:1,cseq:1}}
const tabs=()=>role==='Farmer'?[['home','My produce'],['ord','Orders'],['alerts','Alerts']]:role==='Buyer'?[['home','Market'],['ord','My orders'],['alerts','Alerts']]:role==='Transporter'?[['home','Jobs'],['alerts','Alerts']]:[['home','Overview'],['ord','Orders'],['prices','Prices'],['comps','Complaints'],['alerts','Alerts']];
const L=id=>S.lst.find(x=>x.id===id),O=id=>S.ord.find(x=>x.id===id);
const mkt=p=>S.prices.find(x=>x.p===p);
const rating=f=>{const r=S.ord.filter(o=>o.rating&&L(o.lst).farmer===f).map(o=>o.rating);return r.length?(r.reduce((a,b)=>a+b,0)/r.length).toFixed(1)+' / 5 ('+r.length+')':'no ratings yet'};
function addList(){const p=$('lp').value.trim(),q=+$('lq').value,pr=+$('lr').value,loc=$('ll').value.trim();
 if(!p||!(q>0)||!(pr>0)||!loc)return toast('Fill in the produce, quantity, price and location');
 S.lst.unshift({id:S.seq++,farmer:me,produce:p,qty:q,unit:$('lu').value,price:pr,loc,at:Date.now()});save();toast('Produce listed');draw()}
function listForm(){return card(`<b>List produce for sale</b><label>Produce</label><input id="lp" list="pl" placeholder="e.g. Tomatoes"><datalist id="pl">${S.prices.map(x=>`<option>${esc(x.p)}</option>`).join('')}</datalist>
 <div class="grid"><div><label>Quantity</label><input id="lq" type="number" min="1"></div><div><label>Unit</label><select id="lu"><option>kg</option><option>90kg bag</option><option>crate</option><option>bunch</option></select></div><div><label>Price per unit (KES)</label><input id="lr" type="number" min="1"></div><div><label>Location</label><input id="ll"></div></div>
 <div style="margin-top:12px">${btn('List produce','addList()')}</div>`)}
function lcard(l,buy){const m=mkt(l.produce);
 return card(`<div class="row"><b>${esc(l.produce)}</b><b>${money(l.price)} / ${esc(l.unit)}</b></div><div class="sub">${esc(l.farmer)} · ${esc(l.loc)} · ${l.qty} ${esc(l.unit)} left<br>Rating: ${rating(l.farmer)}${m?`<br>Market average: ${money(m.price)} / ${esc(m.unit)}`:''}</div>${buy&&l.qty>0?`<div style="margin-top:8px;display:flex;gap:8px;align-items:center"><input id="q${l.id}" type="number" min="1" max="${l.qty}" value="1" style="width:90px">${btn('Order','order('+l.id+')')}</div>`:''}${buy&&l.qty<=0?'<div class="sub">Sold out</div>':''}`)}
function order(id){const l=L(id),q=+$('q'+id).value;if(!(q>0)||q>l.qty)return toast('Choose a quantity up to '+l.qty);
 const o={id:S.oseq++,lst:id,buyer:me,qty:q,total:q*l.price,status:'Placed',trans:null,rating:null,at:Date.now(),log:['Order placed']};S.ord.unshift(o);
 notify(`New order #${o.id}: ${q} ${l.unit} of ${l.produce} (${money(o.total)}) from ${me}`,l.farmer);notify(`Order #${o.id} placed. The farmer will respond soon.`,me);save();toast('Order placed');tab='ord';draw()}
function ocard(o,act){const l=L(o.lst);
 return card(`<div class="row"><b>#${o.id} ${esc(l.produce)}</b>${tag(o.status)}</div><div class="sub">${o.qty} ${esc(l.unit)} · ${money(o.total)}<br>Farmer: ${esc(l.farmer)} · Buyer: ${esc(o.buyer)}${o.trans?'<br>Transporter: '+esc(o.trans):''}${o.rating?'<br>Rating given: '+o.rating+' / 5':''}<br>${esc(o.log[o.log.length-1])}</div>${act?oacts(o,l):''}`)}
function oacts(o,l){let h='';
 if(role==='Farmer'&&o.status==='Placed')h=btn('Accept','accept('+o.id+')')+btn('Decline','decline('+o.id+')','ghost');
 if(role==='Transporter'&&o.status==='Accepted'&&!o.trans)h=btn('Take job','take('+o.id+')');
 if(role==='Transporter'&&o.status==='Accepted'&&o.trans===me)h=btn('Start delivery','move('+o.id+',\'In transit\')');
 if(role==='Transporter'&&o.status==='In transit'&&o.trans===me)h=btn('Mark delivered','move('+o.id+',\'Delivered\')');
 if(role==='Buyer'&&o.status==='Delivered')h=(o.rating?'':btn('Rate farmer','rate('+o.id+')'))+btn('Report a problem','report('+o.id+')','ghost');
 return h?`<div style="margin-top:8px">${h}</div>`:''}
function accept(id){const o=O(id),l=L(o.lst);if(l.qty<o.qty)return toast('Not enough stock left for this order');l.qty-=o.qty;o.status='Accepted';o.log.push('Accepted by farmer');
 notify(`Order #${id} was accepted. A transporter will be assigned.`,o.buyer);notify(`Delivery job: ${o.qty} ${l.unit} of ${l.produce} from ${l.loc}`,'role:Transporter');save();draw()}
function decline(id){const o=O(id);o.status='Declined';o.log.push('Declined by farmer');notify(`Order #${id} was declined by the farmer.`,o.buyer);save();draw()}
function take(id){const o=O(id);o.trans=me;o.log.push('Transporter '+me+' took the job');notify(`${me} will deliver order #${id}.`,o.buyer);notify(`${me} will deliver order #${id}.`,L(o.lst).farmer);save();draw()}
function move(id,s){const o=O(id);o.status=s;o.log.push(s);notify(`Order #${id} is now ${s.toLowerCase()}.`,o.buyer);if(s==='Delivered')notify(`Order #${id} was delivered.`,L(o.lst).farmer);save();draw()}
function rate(id){const v=+prompt('Rate the farmer from 1 to 5');if(!(v>=1&&v<=5))return toast('Enter a number from 1 to 5');const o=O(id);o.rating=Math.round(v);notify(`Order #${id} was rated ${o.rating} out of 5.`,L(o.lst).farmer);save();draw()}
function report(id){const t=prompt('What went wrong?');if(!t)return;S.comps.unshift({id:S.cseq++,by:me,ord:id,text:t,status:'Open',at:Date.now()});notify(`New complaint on order #${id}: ${t.slice(0,60)}`,'Admin');notify('Your complaint was sent to the administrator.',me);save();toast('Complaint sent');draw()}
function savePrices(){S.prices.forEach((x,i)=>{const v=+$('pr'+i).value;if(v>0)x.price=v});save();toast('Market prices updated');draw()}
function overview(){const d=S.ord.filter(o=>o.status==='Delivered'),rs=S.ord.filter(o=>o.rating).map(o=>o.rating);
 return `<div class="grid four">${stat(S.lst.filter(l=>l.qty>0).length,'active listings')}${stat(S.ord.filter(o=>['Placed','Accepted','In transit'].includes(o.status)).length,'orders in progress','info')}${stat(money(d.reduce((a,o)=>a+o.total,0)),'delivered sales','ok')}${stat(S.comps.filter(c=>c.status==='Open').length,'open complaints','bad')}</div>
 <div class="card"><b>Orders by status</b>${bars(['Placed','Accepted','In transit','Delivered','Declined'].map(s=>[s,S.ord.filter(o=>o.status===s).length]))}</div>
 <div class="card"><b>Platform rating</b><div class="sub">${rs.length?(rs.reduce((a,b)=>a+b,0)/rs.length).toFixed(1)+' out of 5 from '+rs.length+' ratings':'No ratings yet'}</div></div>`}
function view(){
 if(role==='Farmer')return tab==='ord'?'<h2>Orders for my produce</h2>'+(S.ord.filter(o=>L(o.lst).farmer===me).map(o=>ocard(o,1)).join('')||empty('No orders yet.')):listForm()+'<h2>My produce</h2>'+(S.lst.filter(l=>l.farmer===me).map(l=>lcard(l,0)).join('')||empty('Nothing listed yet.'));
 if(role==='Buyer')return tab==='ord'?'<h2>My orders</h2>'+(S.ord.filter(o=>o.buyer===me).map(o=>ocard(o,1)).join('')||empty('No orders yet.')):'<h2>Fresh produce</h2>'+(S.lst.map(l=>lcard(l,1)).join('')||empty('Nothing for sale yet.'));
 if(role==='Transporter'){const jobs=S.ord.filter(o=>o.status==='Accepted'&&!o.trans),my=S.ord.filter(o=>o.trans===me&&['Accepted','In transit'].includes(o.status));
  return '<h2>Open jobs ('+jobs.length+')</h2>'+(jobs.map(o=>ocard(o,1)).join('')||empty('No jobs waiting.'))+'<h2>My deliveries ('+my.length+')</h2>'+(my.map(o=>ocard(o,1)).join('')||empty('None active.'))}
 if(tab==='ord')return '<h2>All orders</h2>'+(S.ord.map(o=>ocard(o,0)).join('')||empty('No orders yet.'));
 if(tab==='prices')return card('<b>Market prices</b><div class="sub">Farmers and buyers see these as the market average.</div>'+S.prices.map((x,i)=>`<label>${esc(x.p)} (KES per ${esc(x.unit)})</label><input id="pr${i}" type="number" min="1" value="${x.price}">`).join('')+`<div style="margin-top:12px">${btn('Save prices','savePrices()')}</div>`);
 if(tab==='comps')return S.comps.map(c=>card(`<div class="row"><b>${esc(c.by)}</b>${tag(c.status)}</div><div class="sub">Order #${c.ord} · ${ago(c.at)}</div>${esc(c.text)}${c.status==='Open'?`<div style="margin-top:8px">${btn('Mark resolved','resolveC('+c.id+')')}</div>`:''}`)).join('')||empty('No complaints.');
 return overview()}
function resolveC(id){const c=S.comps.find(x=>x.id===id);c.status='Resolved';notify('Your complaint was marked resolved.',c.by);save();draw()}

let S;try{S=JSON.parse(localStorage.getItem(KEY+'_d'))}catch(e){}
if(!S)S=seed();
const save=()=>{try{localStorage.setItem(KEY+'_d',JSON.stringify(S))}catch(e){}};
let tab='home',role='',me='',prof='',mode='login',aerr='';
const key=()=>role==='Admin'?'Admin':(role===PROFROLE&&prof?prof:me);
const notify=(m,who)=>{S.notes.unshift({m,who,at:Date.now(),read:false})};
const mine=()=>S.notes.filter(n=>n.who===key()||n.who==='role:'+role);
const getU=()=>{try{return JSON.parse(localStorage.getItem(KEY+'_users'))||[]}catch(e){return[]}};
const putU=u=>{try{localStorage.setItem(KEY+'_users',JSON.stringify(u))}catch(e){}};
const cur=()=>{try{const e=localStorage.getItem(KEY+'_sess');return getU().find(u=>u.email===e)||null}catch(e){return null}};
async function hash(p,s){const enc=new TextEncoder(),k=await crypto.subtle.importKey('raw',enc.encode(p),'PBKDF2',false,['deriveBits']);
 const b=await crypto.subtle.deriveBits({name:'PBKDF2',salt:enc.encode(s),iterations:100000,hash:'SHA-256'},k,256);
 return Array.from(new Uint8Array(b)).map(x=>x.toString(16).padStart(2,'0')).join('')}
const bad=m=>{aerr=m;const e=$('xerr');if(e)e.textContent=m};
const xrole=()=>{if(PROFROLE)$('xpf').style.display=$('xr').value===PROFROLE?'block':'none'};
function authView(){const reg=mode==='reg';
 return `<div class="card auth"><b>${reg?'Create your account':'Log in'}</b>
 ${reg?`<label>Full name</label><input id="xn" autocomplete="name">`:''}
 <label>Email</label><input id="xe" type="email" autocomplete="email">
 <label>Password</label><input id="xp" type="password" autocomplete="${reg?'new-password':'current-password'}">
 ${reg?`<label>Confirm password</label><input id="xp2" type="password" autocomplete="new-password">
 <label>Account type</label><select id="xr" onchange="xrole()">${ROLES.map(r=>`<option>${r}</option>`).join('')}</select>
 ${PROFROLE?`<div id="xpf" style="display:${ROLES[0]===PROFROLE?'block':'none'}"><label>${PROFLABEL}</label><select id="xl">${PROF.map(p=>`<option>${esc(p)}</option>`).join('')}</select></div>`:''}
 <div class="sub" style="margin-top:8px">The first account created becomes the administrator.</div>`:''}
 <div class="err" id="xerr">${esc(aerr)}</div>
 <div style="margin-top:12px"><button class="btn" onclick="${reg?'doReg()':'doLogin()'}">${reg?'Register':'Log in'}</button></div>
 <div class="sub" style="margin-top:12px">${reg?'Already registered?':'New here?'} <button class="link" onclick="mode='${reg?'login':'reg'}';aerr='';draw()">${reg?'Log in':'Create an account'}</button></div></div>`}
async function doReg(){const n=$('xn').value.trim(),e=$('xe').value.trim().toLowerCase(),p=$('xp').value;
 if(!n)return bad('Enter your full name.');
 if(!/^\S+@\S+\.\S+$/.test(e))return bad('Enter a valid email address.');
 if(p.length<8)return bad('Password must be at least 8 characters.');
 if(p!==$('xp2').value)return bad('Passwords do not match.');
 const us=getU();if(us.some(u=>u.email===e))return bad('That email is already registered. Log in instead.');
 const salt=Array.from(crypto.getRandomValues(new Uint8Array(8))).join('-');
 const r=us.length?$('xr').value:'Admin',pf=(r===PROFROLE)?$('xl').value:'';
 us.push({email:e,name:n,role:r,prof:pf,salt,h:await hash(p,salt)});putU(us);
 try{localStorage.setItem(KEY+'_sess',e)}catch(x){}
 start()}
async function doLogin(){const e=$('xe').value.trim().toLowerCase(),u=getU().find(x=>x.email===e);
 if(!u||u.h!==await hash($('xp').value,u.salt))return bad('Email or password is incorrect.');
 try{localStorage.setItem(KEY+'_sess',e)}catch(x){}
 start()}
function start(){const u=cur();if(!u)return;role=u.role;me=u.name;prof=u.prof||'';tab='home';aerr='';draw()}
function logout(){try{localStorage.removeItem(KEY+'_sess')}catch(e){}mode='login';aerr='';draw()}
function drawNav(){const u=mine().filter(n=>!n.read).length;
 $('nav').innerHTML=tabs().map(([k,l])=>`<button class="${tab===k?'on':''}" onclick="go('${k}')">${l}${k==='alerts'&&u?`<span class="dot">${u}</span>`:''}</button>`).join('')}
const go=k=>{tab=k;draw()};
function alertsView(){const n=mine();n.forEach(x=>x.read=true);save();return n.length?n.map(x=>card(esc(x.m)+`<div class="sub">${ago(x.at)}</div>`)).join(''):empty('No alerts yet.')}
function draw(){const u=cur();$('who').innerHTML=u?`<span>${esc(u.name)} · ${role}</span><button class="btn sm ghost" onclick="logout()">Log out</button>`:'';
 if(!u){$('nav').innerHTML='';$('main').innerHTML=authView();return}
 drawNav();$('main').innerHTML=tab==='alerts'?alertsView():view()}
start();draw();
